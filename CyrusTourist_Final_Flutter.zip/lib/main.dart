import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const CyrusTouristApp());

class CyrusTouristApp extends StatelessWidget {
  const CyrusTouristApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'سایروس توریست',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        colorSchemeSeed: Colors.teal,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  Future<void> _open(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    final categories = [
      ('🏛️', 'تاریخی'),
      ('🌿', 'طبیعت'),
      ('🏕️', 'بوم‌گردی'),
      ('🏨', 'اقامتگاه'),
      ('🗺️', 'راهنمای سفر'),
      ('🧭', 'ابزار سفر'),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('سایروس توریست', style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const DrawerHeader(
              child: Center(
                child: Text('سایروس توریست', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.home),
              title: const Text('صفحه اصلی'),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              leading: const Icon(Icons.hotel),
              title: const Text('ثبت اقامتگاه'),
              onTap: () => _showInfo(context, 'ثبت اقامتگاه', 'بخش ثبت و معرفی اقامتگاه در نسخه‌های بعدی تکمیل می‌شود.'),
            ),
            ListTile(
              leading: const Icon(Icons.person_add),
              title: const Text('ثبت مسافر'),
              onTap: () => _showInfo(context, 'ثبت مسافر', 'بخش ثبت مسافر در نسخه‌های بعدی تکمیل می‌شود.'),
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(12),
          children: [
            Container(
              height: 250,
              clipBehavior: Clip.antiAlias,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(18)),
              child: FlutterMap(
                options: const MapOptions(
                  initialCenter: LatLng(35.6892, 51.3890),
                  initialZoom: 5.5,
                ),
                children: [
                  TileLayer(
                    urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                    userAgentPackageName: 'ir.cyrustourist.app',
                  ),
                  const MarkerLayer(
                    markers: [
                      Marker(
                        point: LatLng(35.6892, 51.3890),
                        width: 44,
                        height: 44,
                        child: Icon(Icons.location_pin, size: 44, color: Colors.red),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              decoration: InputDecoration(
                hintText: 'جستجوی شهر، جاذبه یا اقامتگاه...',
                prefixIcon: const Icon(Icons.search),
                filled: true,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Text('دسته‌بندی گردشگری', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: categories.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                crossAxisSpacing: 8,
                mainAxisSpacing: 8,
                childAspectRatio: 1.1,
              ),
              itemBuilder: (_, i) => Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => _showInfo(context, categories[i].$2, 'محتوای این بخش به‌زودی در دسترس قرار می‌گیرد.'),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(categories[i].$1, style: const TextStyle(fontSize: 30)),
                      const SizedBox(height: 5),
                      Text(categories[i].$2),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 18),
            const Text('فیلم‌های گردشگری و اقامتی', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            _videoCard(context, 'گردشگری ایران', 'معرفی جاذبه‌ها و طبیعت ایران'),
            _videoCard(context, 'اقامت و بوم‌گردی', 'معرفی اقامتگاه‌ها و تجربه سفر'),
            const SizedBox(height: 18),
            const Text('ما را دنبال کنید', textAlign: TextAlign.center, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(onPressed: () => _open('https://www.instagram.com/cyrustourist/'), icon: const Icon(Icons.camera_alt, size: 32)),
                IconButton(onPressed: () => _open('https://youtube.com/@cyrustourist'), icon: const Icon(Icons.play_circle_fill, size: 36)),
                IconButton(onPressed: () => _open('https://www.aparat.com/Cyrustourist'), icon: const Icon(Icons.video_library, size: 32)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _videoCard(BuildContext context, String title, String subtitle) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        leading: const CircleAvatar(child: Icon(Icons.play_arrow)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.arrow_forward_ios, size: 16),
        onTap: () => _showInfo(context, title, 'لینک ویدئو را می‌توان در این بخش اضافه کرد.'),
      ),
    );
  }

  void _showInfo(BuildContext context, String title, String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('باشه'))],
      ),
    );
  }
}
